//
//  BTCData.swift
//  OneBTC
//
//  Created by Sezer İltekin on 29.01.2023.
//

struct BTCData: Decodable {
    var rate: Double
}
