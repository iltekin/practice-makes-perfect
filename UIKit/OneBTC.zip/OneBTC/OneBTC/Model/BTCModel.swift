//
//  BTCModel.swift
//  OneBTC
//
//  Created by Sezer İltekin on 29.01.2023.
//

struct BTCModel {
    var rate: Double
}
