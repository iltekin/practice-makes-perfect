//
//  ViewController.swift
//  OneBTC
//
//  Created by Sezer İltekin on 26.01.2023.
//

import UIKit

protocol BTCManagerDelegate {
    func updatePrice(price: Double)
}

class MainViewController: UIViewController, BTCManagerDelegate {
    
    @IBOutlet weak var currencyImage: UIImageView!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var currencyPickerView: UIPickerView!
    
    var CM = CurrencyManager()
    var btcManager = BTCManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        btcManager.delegate = self
        updatePrice()
        
        currencyPickerView.dataSource = self
        currencyPickerView.delegate = self
    }
    
    func updatePrice(price: Double) {
        DispatchQueue.main.async {
            self.priceLabel.text = String(Int(price))
            self.currencyImage.image = self.CM.getImage()
        }
    }
    
    func updatePrice() {
        btcManager.fetch(currency: CM.current ?? "USD")
    }
    
}

extension MainViewController: UIPickerViewDataSource, UIPickerViewDelegate {
        
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return CM.currencies.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return CM.currencies[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        CM.setCurrent(index: row)
        updatePrice()
    }
    
}

